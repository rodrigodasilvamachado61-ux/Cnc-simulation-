package com.example.cncsimulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

// --- Simplified/expanded CNC simulator main activity ---
// This file contains the Kotlin Compose UI + parser and simulation.
// It's based on the code prepared in our conversation and intended to be a ready-to-build example.

sealed class CncCmd {
    data class Move(val rapid: Boolean, val x: Double?, val z: Double?, val feed: Double?) : CncCmd()
    data class Arc(val cw: Boolean, val x: Double?, val z: Double?, val i: Double?, val k: Double?, val feed: Double?) : CncCmd()
    data class Spindle(val on: Boolean) : CncCmd()
    data class SpindleSpeed(val s: Double) : CncCmd()
    data class Tool(val t: Int, val offset: Double = 0.0) : CncCmd()
    data class Raw(val text: String) : CncCmd()
    data class CycleDrill(val x: Double?, val z: Double?, val r: Double?, val q: Int?) : CncCmd()
    data class CycleThread(val x: Double?, val z: Double?, val passDepth: Double?) : CncCmd()
    data class SetMode(val absolute: Boolean) : CncCmd()
}

fun parseProgramExtended(text: String, dialectSiemens: Boolean = false): List<CncCmd> {
    val out = mutableListOf<CncCmd>()
    var absolute = true
    for (rawLine in text.lines()) {
        var line = rawLine.trim()
        if (line.isEmpty()) continue
        line = line.substringBefore('(').substringBefore(';').trim()
        if (line.isEmpty()) continue
        val toks = line.split(Regex("\\s+"))
        var g: Int? = null
        var m: Int? = null
        var x: Double? = null
        var z: Double? = null
        var i: Double? = null
        var k: Double? = null
        var f: Double? = null
        var s: Double? = null
        var t: Int? = null
        var extraText = mutableListOf<String>()
        for (tok in toks) {
            if (tok.isBlank()) continue
            val up = tok.uppercase()
            when {
                up.startsWith("G") && up.length > 1 -> g = up.substring(1).toDoubleOrNull()?.toInt()
                up.startsWith("M") && up.length > 1 -> m = up.substring(1).toDoubleOrNull()?.toInt()
                up.startsWith("X") -> x = up.substring(1).toDoubleOrNull()
                up.startsWith("Z") -> z = up.substring(1).toDoubleOrNull()
                up.startsWith("I") -> i = up.substring(1).toDoubleOrNull()
                up.startsWith("K") -> k = up.substring(1).toDoubleOrNull()
                up.startsWith("F") -> f = up.substring(1).toDoubleOrNull()
                up.startsWith("S") -> s = up.substring(1).toDoubleOrNull()
                up.startsWith("T") -> t = up.substring(1).toDoubleOrNull()?.toInt()
                up == "G90" -> { absolute = true; out += CncCmd.SetMode(true) }
                up == "G91" -> { absolute = false; out += CncCmd.SetMode(false) }
                up.startsWith("CYCLE_DRILL") -> {
                    val joined = (up + " " + toks.joinToString(" "))
                    val xArg = Regex("X([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    val zArg = Regex("Z([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    val rArg = Regex("R([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    val qArg = Regex("Q([0-9]+)").find(joined)?.groups?.get(1)?.value?.toIntOrNull()
                    out += CncCmd.CycleDrill(xArg, zArg, rArg, qArg)
                }
                up.startsWith("CYCLE_THREAD") -> {
                    val joined = (up + " " + toks.joinToString(" "))
                    val xArg = Regex("X([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    val zArg = Regex("Z([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    val pArg = Regex("P([-+]?[0-9]*\\.?[0-9]+)").find(joined)?.groups?.get(1)?.value?.toDoubleOrNull()
                    out += CncCmd.CycleThread(xArg, zArg, pArg)
                }
                else -> extraText.add(tok)
            }
        }
        if (m != null) {
            when (m) {
                3 -> out += CncCmd.Spindle(true)
                5 -> out += CncCmd.Spindle(false)
                else -> out += CncCmd.Raw("M$m")
            }
        }
        if (s != null) out += CncCmd.SpindleSpeed(s)
        if (t != null) out += CncCmd.Tool(t, 0.0)
        if (g != null) {
            when (g) {
                0 -> out += CncCmd.Move(true, x, z, f)
                1 -> out += CncCmd.Move(false, x, z, f)
                2 -> out += CncCmd.Arc(true, x, z, i, k, f)
                3 -> out += CncCmd.Arc(false, x, z, i, k, f)
                else -> out += CncCmd.Raw("G$g")
            }
        } else if (x != null || z != null) {
            out += CncCmd.Move(true, x, z, f)
        } else if (extraText.isNotEmpty()) {
            out += CncCmd.Raw(extraText.joinToString(" "))
        }
    }
    return out
}

// simple helpers
fun linspace(a: Double, b: Double, n: Int): List<Double> {
    if (n <= 1) return listOf(b)
    val out = mutableListOf<Double>()
    for (i in 0 until n) out.add(a + (b - a) * (i.toDouble() / (n - 1)))
    return out
}

fun arcPoints(startX: Double, startZ: Double, endX: Double, endZ: Double, i: Double, k: Double, cw: Boolean, steps: Int = 40): List<Pair<Double, Double>> {
    val cx = startX + (i)
    val cz = startZ + (k)
    val r = hypot(startX - cx, startZ - cz)
    var startAng = atan2(startZ - cz, startX - cx)
    var endAng = atan2(endZ - cz, endX - cx)
    val twoPi = 2.0 * Math.PI
    var sweep = if (cw) {
        var s = startAng - endAng
        if (s <= 0) s += twoPi
        -s
    } else {
        var s = endAng - startAng
        if (s <= 0) s += twoPi
        s
    }
    val pts = mutableListOf<Pair<Double, Double>>()
    val n = steps.coerceAtLeast(6)
    for (t in 0..n) {
        val frac = t.toDouble() / n.toDouble()
        val ang = startAng + (if (cw) -1 else 1) * sweep * frac
        val x = cx + r * cos(ang)
        val z = cz + r * sin(ang)
        pts.add(x to z)
    }
    return pts
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CncSimulatorExpandedApp() }
    }
}

@Composable
fun CncSimulatorExpandedApp() {
    val scope = rememberCoroutineScope()
    var programText by remember { mutableStateOf(sampleProgram()) }
    var dialectSiemens by remember { mutableStateOf(false) }
    var commands by remember { mutableStateOf(parseProgramExtended(programText, dialectSiemens)) }

    var currentIndex by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var speed by remember { mutableStateOf(1.0f) }
    var logText by remember { mutableStateOf("") }

    val zMin = -80.0
    val zMax = 80.0
    val initialRadius = 40.0
    val samples = 600
    val profile = remember { DoubleArray(samples) { initialRadius } }

    var curX by remember { mutableStateOf(initialRadius) }
    var curZ by remember { mutableStateOf(0.0) }
    var spindleOn by remember { mutableStateOf(false) }
    var spindleS by remember { mutableStateOf(0.0) }
    var curTool by remember { mutableStateOf(1) }
    var absoluteMode by remember { mutableStateOf(true) }
    var rotationDeg by remember { mutableStateOf(0f) }

    fun resetAll() {
        for (i in profile.indices) profile[i] = initialRadius
        curX = initialRadius
        curZ = 0.0
        currentIndex = 0
        logText = ""
        spindleOn = false
        spindleS = 0.0
        rotationDeg = 0f
        absoluteMode = true
    }

    fun cutAt(zVal: Double, xVal: Double) {
        val idx = ((zVal - zMin) / (zMax - zMin) * (profile.size - 1)).roundToInt().coerceIn(0, profile.size - 1)
        profile[idx] = min(profile[idx], xVal.coerceAtLeast(0.0))
    }

    LaunchedEffect(programText, dialectSiemens) { commands = parseProgramExtended(programText, dialectSiemens) }

    LaunchedEffect(playing, speed, commands) {
        if (playing) {
            while (playing && currentIndex < commands.size) {
                val cmd = commands[currentIndex]
                executeCmd(cmd, profile, ::cutAt, { x,z -> curX = x; curZ = z }, { spindleOn = it }, { spindleS = it }, { curTool = it }, { absoluteMode = it }, zMin, zMax, initialRadius, speed)
                logText += "> ${'$'}{describeCmd(cmd)}\n"
                currentIndex++
                rotationDeg = (rotationDeg + 15f * speed).rem(360f)
                delay((80L / speed).coerceAtLeast(20L))
            }
            playing = false
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Torno CNC - Simulador") }) }) { padding ->
        Column(Modifier.padding(padding).padding(10.dp).fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = programText, onValueChange = { programText = it }, modifier = Modifier.weight(1f).height(160.dp), singleLine = false)
                Spacer(Modifier.width(8.dp))
                Column {
                    Button(onClick = { programText = sampleProgram() }) { Text("Load exemplo") }
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { resetAll(); commands = parseProgramExtended(programText, dialectSiemens) }) { Text("Reset") }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = dialectSiemens, onCheckedChange = { dialectSiemens = it })
                        Text("Siemens dialect")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (currentIndex < commands.size) {
                        val cmd = commands[currentIndex]
                        scope.launch {
                            executeCmd(cmd, profile, ::cutAt, { x,z -> curX = x; curZ = z }, { spindleOn = it }, { spindleS = it }, { curTool = it }, { absoluteMode = it }, zMin, zMax, initialRadius, speed)
                            logText += "> ${'$'}{describeCmd(cmd)}\n"
                            currentIndex++
                        }
                    }
                }) { Icon(Icons.Default.SkipNext, contentDescription = "Step") }

                IconButton(onClick = { playing = !playing }) {
                    if (playing) Icon(Icons.Default.Pause, contentDescription = "Pause") else Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                }

                Text("Velocidade")
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.2f..3.0f, modifier = Modifier.width(200.dp))
                Text(String.format("%.2fx", speed))
                Spacer(Modifier.weight(1f))
                Text("Cmd ${'$'}{currentIndex}/${'$'}{commands.size}")
            }
            Spacer(Modifier.height(10.dp))
            Box(modifier = Modifier.fillMaxWidth().height(340.dp).border(1.dp, MaterialTheme.colors.onSurface.copy(alpha = 0.12f))) {
                SimulationCanvasAdvanced(profile, zMin, zMax, curX, curZ, rotationDeg, initialRadius)
                Column(modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).background(MaterialTheme.colors.surface.copy(alpha = 0.9f)).padding(6.dp)) {
                    Text("Spindle: ${'$'}{if (spindleOn) "ON" else "OFF"} ${'$'}{if (spindleS>0) "S=${'$'}{spindleS.toInt()}" else ""}")
                    Text("Tool: T${'$'}{curTool}")
                    Text("Pos X=${'$'}{"%.2f".format(curX)} Z=${'$'}{"%.2f".format(curZ)}")
                    Text("Mode: ${'$'}{if (absoluteMode) "ABS" else "REL"}")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row {
                Button(onClick = { /* dummy for export in minimal project */ }) { Text("Exportar SVG") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { /* dummy */ }) { Text("Exportar CSV") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { commands = parseProgramExtended(programText, dialectSiemens) }) { Text("Parsear") }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Comandos parseados:", style = MaterialTheme.typography.subtitle1)
                    Column(modifier = Modifier.verticalScroll(rememberScrollState()).height(160.dp)) {
                        for ((i, c) in commands.withIndex()) {
                            Text("${'$'}{i+1}: ${'$'}{describeCmd(c)}", color = if (i==currentIndex) MaterialTheme.colors.primary else MaterialTheme.colors.onSurface)
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Log:", style = MaterialTheme.typography.subtitle1)
                    Box(modifier = Modifier.verticalScroll(rememberScrollState()).height(160.dp).fillMaxWidth().border(1.dp, MaterialTheme.colors.onSurface.copy(alpha = 0.08f)).padding(6.dp)) {
                        Text(logText)
                    }
                }
            }
        }
    }
}

fun describeCmd(c: CncCmd): String = when (c) {
    is CncCmd.Move -> "${'$'}{if (c.rapid) "G0" else "G1"} X=${'$'}{c.x ?: "-"} Z=${'$'}{c.z ?: "-"} F=${'$'}{c.feed ?: "-"}"
    is CncCmd.Arc -> "${'$'}{if (c.cw) "G2" else "G3"} X=${'$'}{c.x ?: "-"} Z=${'$'}{c.z ?: "-"} I=${'$'}{c.i ?: "-"} K=${'$'}{c.k ?: "-"}"
    is CncCmd.Spindle -> if (c.on) "M3" else "M5"
    is CncCmd.SpindleSpeed -> "S ${'$'}{c.s}"
    is CncCmd.Tool -> "T${'$'}{c.t}"
    is CncCmd.Raw -> "RAW ${'$'}{c.text}"
    is CncCmd.CycleDrill -> "CYCLE_DRILL X=${'$'}{c.x} Z=${'$'}{c.z} R=${'$'}{c.r} Q=${'$'}{c.q}"
    is CncCmd.CycleThread -> "CYCLE_THREAD X=${'$'}{c.x} Z=${'$'}{c.z} P=${'$'}{c.passDepth}"
    is CncCmd.SetMode -> "MODE ${'$'}{if (c.absolute) "ABS" else "REL"}"
}

suspend fun executeCmd(
    cmd: CncCmd,
    profile: DoubleArray,
    cutAt: (Double, Double) -> Unit,
    setPos: (Double, Double) -> Unit,
    setSpindle: (Boolean) -> Unit,
    setSpindleS: (Double) -> Unit,
    setTool: (Int) -> Unit,
    setMode: (Boolean) -> Unit,
    zMin: Double,
    zMax: Double,
    initialRadius: Double,
    speed: Float
) {
    when (cmd) {
        is CncCmd.Move -> {
            val targetX = cmd.x ?: (profile.maxOrNull() ?: initialRadius)
            val targetZ = cmd.z ?: 0.0
            val nsteps = (20 * speed).toInt().coerceAtLeast(6)
            val xs = linspace((profile.maxOrNull() ?: initialRadius), targetX, nsteps)
            val zs = linspace(0.0, targetZ, nsteps)
            for (i in xs.indices) {
                setPos(xs[i], zs[i])
                if (!cmd.rapid) {
                    cutAt(zs[i], xs[i])
                }
                delay((12L / speed).coerceAtLeast(6L))
            }
        }
        is CncCmd.Arc -> {
            val startX = (profile.maxOrNull() ?: initialRadius)
            val startZ = 0.0
            val ex = cmd.x ?: startX
            val ez = cmd.z ?: startZ
            val pts = arcPoints(startX, startZ, ex, ez, cmd.i ?: 0.0, cmd.k ?: 0.0, cmd.cw, steps = 40)
            for ((x, z) in pts) {
                setPos(x, z)
                cutAt(z, x)
                delay((10L / speed).coerceAtLeast(6L))
            }
        }
        is CncCmd.Spindle -> setSpindle(cmd.on)
        is CncCmd.SpindleSpeed -> setSpindleS(cmd.s)
        is CncCmd.Tool -> setTool(cmd.t)
        is CncCmd.CycleDrill -> {
            val x = cmd.x ?: 0.0
            val z = cmd.z ?: -10.0
            val q = cmd.q ?: 1
            val r = cmd.r ?: 1.0
            var curZ = 0.0
            for (i in 1..q) {
                val stepZ = curZ + (z - curZ) * (i.toDouble() / q)
                val zs = linspace(curZ, stepZ, 8)
                for (zz in zs) {
                    setPos(x, zz)
                    cutAt(zz, x)
                    delay((30L / speed).coerceAtLeast(12L))
                }
                val rzs = linspace(stepZ, r, 6)
                for (rz in rzs) { setPos(x, rz); delay((20L / speed).coerceAtLeast(10L)) }
                curZ = stepZ
            }
        }
        is CncCmd.CycleThread -> {
            val x = cmd.x ?: 10.0
            val z = cmd.z ?: -10.0
            val p = cmd.passDepth ?: 1.0
            val steps = 24
            val xs = linspace((profile.maxOrNull() ?: initialRadius), x, steps)
            val zs = linspace(0.0, z, steps)
            for (i in xs.indices) {
                setPos(xs[i], zs[i])
                cutAt(zs[i], xs[i] - p)
                delay((18L / speed).coerceAtLeast(8L))
            }
        }
        is CncCmd.Raw -> {}
        is CncCmd.SetMode -> setMode(cmd.absolute)
    }
}

@Composable
fun SimulationCanvasAdvanced(profile: DoubleArray, zMin: Double, zMax: Double, curX: Double, curZ: Double, rotationDeg: Float, initialRadius: Double) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val centerY = h / 2f
        fun mapZ(z: Double): Float {
            val t = ((z - zMin) / (zMax - zMin)).coerceIn(0.0, 1.0)
            return (t * w).toFloat()
        }
        fun mapX(x: Double): Float {
            val maxRadius = max(initialRadius, (profile.maxOrNull() ?: initialRadius))
            val t = (x / (maxRadius * 1.05)).coerceIn(0.0, 1.0)
            return (centerY - t * (h * 0.42)).toFloat()
        }
        drawRect(color = androidx.compose.ui.graphics.Color(0xFFF7FAFF))
        drawLine(androidx.compose.ui.graphics.Color.LightGray, Offset(0f, centerY), Offset(w, centerY), strokeWidth = 1f)

        val path = Path().apply {
            moveTo(0f, mapX(profile[0]))
            for (i in 1 until profile.size) {
                val z = zMin + (zMax - zMin) * (i.toDouble() / (profile.size - 1))
                lineTo(mapZ(z), mapX(profile[i]))
            }
            lineTo(w, centerY)
            lineTo(0f, centerY)
            close()
        }
        drawPath(path, color = androidx.compose.ui.graphics.Color(0xFFBFD6E0))

        val outline = Path().apply {
            moveTo(0f, mapX(profile[0]))
            for (i in 1 until profile.size) {
                val z = zMin + (zMax - zMin) * (i.toDouble() / (profile.size - 1))
                lineTo(mapZ(z), mapX(profile[i]))
            }
        }
        drawPath(outline, color = androidx.compose.ui.graphics.Color.Black, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))

        val stripes = 12
        for (s in 0 until stripes) {
            val angle = rotationDeg + s * (360f / stripes)
            val cx = w * 0.05f
            val cy = centerY
            val rOut = (h * 0.42f)
            val rIn = rOut * 0.1f
            val ax = cx + cos(Math.toRadians(angle.toDouble())).toFloat() * rIn
            val ay = cy + sin(Math.toRadians(angle.toDouble())).toFloat() * rIn
            val bx = cx + cos(Math.toRadians(angle.toDouble())).toFloat() * rOut
            val by = cy + sin(Math.toRadians(angle.toDouble())).toFloat() * rOut
            drawLine(androidx.compose.ui.graphics.Color.DarkGray.copy(alpha = 0.12f), Offset(ax, ay), Offset(bx, by), strokeWidth = 3f)
        }

        val tx = mapZ(curZ)
        val ty = mapX(curX)
        drawRect(androidx.compose.ui.graphics.Color(0xFFD9534F), topLeft = Offset(tx - 18f, ty - 6f), size = androidx.compose.ui.geometry.Size(18f, 12f))
        drawCircle(androidx.compose.ui.graphics.Color.Black, radius = 3f, center = Offset(tx - 9f, ty))
    }
}

fun sampleProgram(): String {
    return """(Exemplo estendido com arco e ciclo)
T1
S800
M3
G0 X40 Z0
G1 X30 Z5 F120
G2 X10 Z5 I-10 K0 F80
G3 X30 Z20 I10 K0 F80
CYCLE_DRILL X20 Z-30 R5 Q3
CYCLE_THREAD X15 Z-40 P0.5
M5
""".trimIndent()
}