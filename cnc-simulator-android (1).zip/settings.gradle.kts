rootProject.name = "cnc-simulator"
include(":app")